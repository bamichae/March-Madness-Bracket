////////////////////////////////////////////////////////////////////////////////////////////////
//
// File name         : team.h
//
// This file holds the header for the Team struct
//
// Programmer        : Ben Michaels
//
// Date created      : 3 / 02 / 2015
//
// Date last revised : 3 / 30 / 2015
//
////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TEAM_H_
#define TEAM_H_

#include <iostream>  // for io
#include <string>    // for string


using namespace std;

struct Team
{
	
	int position;   // position of the team
	string name;  // team name
	int wins;    // wins 
	int losses;  // losses
	int votes;  // current votes
	int prevPos;  // previous position

	bool operator <(const Team right)  // overloaded equality operator
	{
		if (this->votes < right.votes)     // determine which is less than based on votes
			return false;
		else if (this->votes > right.votes)
			return true;
		
		else if (this->votes == right.votes)
		{
			if (this->wins < right.votes)
				return false;
			else if (this->wins < right.votes)
				return true;
		}
	}

};








#endif TEAM_H_