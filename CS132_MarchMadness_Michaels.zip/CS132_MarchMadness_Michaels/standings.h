////////////////////////////////////////////////////////////////////////////////////////////////
//
// File name         : standings.h
//
// This file holds the headers for the Standings class
//
// Programmer        : Ben Michaels
//
// Date created      : 3 / 3 / 2015
//
// Date last revised : 3 / 30 / 2015
//
////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef STANDINGS_H_
#define STANDINGS_H_

#include "team.h"
#include <iostream>
#include <list>

using namespace std;

class Standings : public list<Team>
{
public :

	string getInputFileName(ifstream   &inFile);  // file name
	string readFile();    // read the file
	void addElements();   // add elements
	int adjust();    // adjust the standings
	void display();  // display them
	void displayAll();  // display all
	void outFile();  // outfile
	Standings();   // constructor
	int remove();  // remove
	Standings(Standings& s);   // copy constructor
	void menu();     // menu
	~Standings();  // destructor
	
private:
list<Team> L1;  // list
string date;  // date

};







#endif STANDINGS_H_