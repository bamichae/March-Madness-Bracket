/*************************************************************
**
** Programmer     : Ben Michaels
**
** Instructor     : Mr. Streller
**
** Course         : CS-132
**
** Date Created   : 3/2/2015
**
** Date Revised   : 3/30/2015
**
** Program Name   : Project2
**
** File Name      : project2_driver.cpp
**
** Input Files    : ncaa_standings.txt
**
** Output Files   : user choice
**
** Purpose        : This program creates a standings
**                  for a team that can be updated and manipulated
**
**
***************************************************************/


#include "standings.h"

#include <iostream>  // for i/o
#include <list>  // list STL class



using namespace std;



int main(){

	Standings S; // create a class instance


	char c = getchar();
	cout << " ";
	return 0;
} // end main