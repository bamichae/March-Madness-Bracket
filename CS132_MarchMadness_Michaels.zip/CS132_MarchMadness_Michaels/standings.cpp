////////////////////////////////////////////////////////////////////////////////////////////////
//
// File name         : standings.cpp
//
// This file holds the definitions for the Standings class
//
// Programmer        : Ben Michaels
//
// Date created      : 3 / 02 / 2015
//
// Date last revised : 3/ 30 / 2015
//
////////////////////////////////////////////////////////////////////////////////////////////////

#include "standings.h"
#include "team.h"

#include <iostream>  // for i/o
#include <list>    // STL list
#include <fstream>  // for file reading
#include <cstring>  // for cstring
#include <string>   // for string
#include <iomanip>   // for setw



using namespace std;


//************************************************************
//
// Function name: Standings()
//
// Purpose: Constructor
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: none
//               
//
//************************************************************
Standings::Standings()
{
	
	menu();  // call menu

}

//************************************************************
//
// Function name: Standings(Standings7 s)
//
// Purpose: Standings copy constructor
//             
//
// Input parameters: none
//
// Output parameters: Standings& s
//
// Return Value: none
//               
//
//************************************************************

Standings::Standings(Standings& s)
{

}

//************************************************************
//
// Function name: ~Standings()
//
// Purpose: destructor
//              
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: none
//
//************************************************************
Standings::~Standings()
{

}

//************************************************************
//
// Function name: getInputFileName
//
// Purpose: to prompt for the fully qualified name of a file
//              i.e. including the path of the file
//
// Input parameters: none
//
// Output parameters: ifstream &inFile
//
// Return Value: a string containing the fully qualified name
//               of a file
//
//************************************************************

string Standings::getInputFileName(ifstream   &inFile)
{
	string inFileName;

	cout << " \n Please enter the fully qualified name of \n"
		<< " the input text file, including the path: \n";

	cin >> inFileName;

	cout << endl;

	inFile.open(inFileName.c_str(),ios::in);                                    //try to open

	if (!inFile)                                                      //test if open
	{
		cerr << " cannot open file: " << inFileName << endl << endl;
		exit(-1);
	}

	return inFileName;
}


//************************************************************
//
// Function name: readFile()
//
// Purpose: To read in the file
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: string file name
//
//************************************************************

string Standings::readFile()
{
	ifstream inFile;  // for infile
	char c,e;      // to read letters
	Team t1;     // to store in strct
	string s1, s2,s3;        // to read in date
	list<Team>::iterator it;    // iterator
	int k = 0;    // for loops
	
	
	getInputFileName(inFile);  // get fike

	inFile >> s1 >> s2 >> s3;   // read in dtae
	s1 += ' ' + s2 + ' ' + s3;
	
	while (!inFile.eof())   // while not end of file 
	{
		inFile >> t1.position;    // position  

		
			c = 0;             //make c something
			inFile >> ws;   // bring in white space
			inFile >> t1.name >> ws;  // eat the name
			c = inFile.peek();  // peek for the next character
			
			if (c > 64 && c < 91)    // if its a letter read it
			{
				inFile >> s2;
				t1.name += ' ' + s2;
			}
			
	
		
		inFile >> t1.wins;    // wins
		inFile >> e;      // hyphen
		inFile >> t1.losses;  // losses
		inFile >> t1.votes;  // votes
		inFile >> ws;
		c = inFile.peek();  // if hyphen in losses spot, read in a 0
		if (c == '-')
		{
			inFile.get(c);
			t1.prevPos = 0;
		}
		else                   // if no hyphen, read it in
		inFile >> t1.prevPos;
	

		if (inFile.eof())
			break;

        L1.push_back(t1);   // make a new node
	}

	L1.sort();   // sort

	it = L1.begin();             // iterate
	for (; it != L1.end(); it++)
	{
		if (it->votes == 0)      // check to see if 0 votes, if so delete that node
			L1.erase(it);
	}

	
	date = s1;     // set the date

	return s1;
	
}

//************************************************************
//
// Function name: addElements()
//
// Purpose: To add teams
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: none
//
//************************************************************

void Standings::addElements()
{
	Team T;   // struct
	list<Team>::iterator it;   // iterator
	int i = 0;    // for loop
	int ans;

	
	cout << "\nHow many teams do you wish to add?\n";   
		cin >> ans;

		while (ans < 1 || ans > 50)
		{
			cout << "\nInvalid Entry. Re-enter\n";
			cin >> ans;
		}

		for (int j = 0; j < ans; j++)
		{
			cout << "\nEnter the name of the college to add\n";
			cin.ignore();
			fflush(stdin);   // flush the buffer
			getline(cin, T.name);
			it = L1.begin();            // check to see if the college exists already
			for (; it != L1.end(); it++)
			{
				if (it->name == T.name)
				{
					cout << "\nCollege already exists. Enter again\n";
					
					fflush(stdin);
					getline(cin, T.name);
				}
			}

			cout << "\nEnter the wins the college has\n";
			cin >> T.wins;
			while (T.wins < 0 || T.wins >100)
			{
				cout << "\nInvalid wins. Re-enter\n";
				cin >> T.wins;
				
			}

			cout << "\nEnter the losses the college has\n";
			cin >> T.losses;
			while (T.losses < 0 || T.losses >100)
			{
				cout << "\nInvalid losses. Re-enter\n";
				cin >> T.losses;

			}

			cout << "\nEnter the votes the college has\n";
			cin >> T.votes;
			while (T.votes < 1 || T.votes > 9999)
			{
				cout << "\nInvalid votes. Re-enter\n";
				cin >> T.votes;

			}
			

			T.prevPos = -1;       // make the prev pos -1 so it wont read in 0 if its a 0

			L1.push_back(T);   // Make a node
		}

	L1.sort();  // sort

	

	it = L1.begin();
	for (; it != L1.end(); it++)
	{

		if (it->prevPos > 0 && it->prevPos < 26)   // adjust the position
			it->prevPos = it->position;

		else if (it->prevPos == 0)        // if zero, the previous position is the new position
			it->prevPos = it->position;

		else if (it->prevPos == -1)    // if -1, the prev position is 0
			it->prevPos = 0;

		it->position = ++i;  // increment the position

	}
	
}

//************************************************************
//
// Function name: adjust()
//
// Purpose: Adjusts the standings
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: int
//
//************************************************************
int Standings::adjust()
{
	Team T;    // struct
	list<Team>::iterator it;  // iterator
	int i=0;   // for loop
	int ans;  // for teams ans
	int k = 0;  // for loop
	int j = 0;  // for loops
	
	
	cout << "\nHow many teams do you wish to update?\n";
	cin >> ans;

	for (it = L1.begin(); it != L1.end(); it++) // how many teams there are
		k++;
	
	while (ans < 0 || ans > k)   // if not enough teams, you cant update
	{
		cout << "\nInvalid entry. Enter again\n";
		cin >> ans;
	}
	

	for (int i = 0; i < ans; i++)
	{
		cout << "\n\nEnter the name of the college being adjusted\n";   
		cin.ignore();
		getline(cin, T.name);

		cout << "\nEnter the wins the college has\n";
		cin >> T.wins;
		while (T.wins < 0 || T.wins >100)      // error check
		{
			cout << "\nInvalid wins. Re-enter\n";
			cin >> T.wins;

		}

		cout << "\nEnter the losses the college has\n";
		cin >> T.losses;
		while (T.losses < 0 || T.losses >100)
		{
			cout << "\nInvalid losses. Re-enter\n";
			cin >> T.losses;

		}

		cout << "\nEnter the votes the college has\n";
		cin >> T.votes;
		while (T.votes <= 0 || T.votes > 9999)
		{
			cout << "\nInvalid votes. Re-enter\n";
			cin >> T.votes;

		}


		it = L1.begin();

		for (; it != L1.end(); it++)     // loops through teams
		{
			j++;

			if (it->name == T.name)   // if the team exists, break
			{
				it->wins = T.wins;
				it->losses = T.losses;
				it->votes = T.votes;
				break;
			}

			else if (j == k)    // else tell them there are none
			{
				cout << "\nNo such team found\n";
				return 0;
			}

		}
	}

	L1.sort();        // update the list
	it = L1.begin();
	for (; it != L1.end(); it++)
			it->prevPos = it->position;

	it = L1.begin();
	for (; it != L1.end(); it++)
	{
		it->position = ++i;

	}
	

	return 0;
}

//************************************************************
//
// Function name: display()
//
// Purpose: To display the top 25 
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: none
//
//************************************************************
void Standings::display()
{
	list<Team>::iterator it;
	

	cout << "\nAs of " << date << " the current AP top ncaa teams are:\n\n";
	cout << "Rank" << "  Team" << "             Record"  << "  Votes" << "  Previous\n";


	it = L1.begin();


	for (int i = 0; i < 25; i++)
	{

		if (it->position < 10)             // for spacing
			cout << it->position << "   ";
		else	
		cout  << it->position << "  ";    // for spacing

		cout <<  it->name;
		for (int i = 0; i < (20 - it->name.length()); i++)
			cout << ' ';
		cout << it->wins;
		
		cout << '-' << it->losses;
		if (it->losses < 10)
			cout << ' ';
		if (it->wins < 10)
			cout << ' ';
			cout << "  " << it->votes;
		
		

		if (it->votes > -1 && it->votes < 10)   // for the votes spacing to make aestetically pleasing
			cout << "      ";
		else if (it->votes > 9 && it->votes < 100)
			cout << "     ";
		else if (it->votes > 99 && it->votes < 1000)
			cout << "    ";
		else if (it->votes > 999 && it->votes < 10000)
			cout << "   ";

		if (it->prevPos == 0)
			cout << '-';
		else
		cout  << it->prevPos;
		cout << endl;
		it++;
	}
}

//************************************************************
//
// Function name: remove()
//
// Purpose: To remove a team
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: int
//
//************************************************************

 
int Standings::remove()
{
	list<Team>::iterator it;   // for iterator
	string temp;   // to hold garbage
	int ans;   // to catch answer
	int hold;  // to hold
	int i = 0;  // for loop
	int j = 0;  // for loop
	int k = 0; // for the loop
	
	cout << "\nHow many teams do you wish to delete?\n";
	cin >> ans;
	 
	hold = ans;

	it = L1.begin();            // for looping 
	for (; it != L1.end(); it++)
		i++;

	while (ans < 1 || ans > i)
	{
		cout << "\nInvalid answer. Enter again\n";
		cin >> ans;
		
	}
	hold = ans;

	if ((i - ans) < 25)       // to check if enough teams
	{
		cout << "\nNot enough teams to delete\n";
		return 0;
	}

	 
	L1.sort();          // update the list
	it = L1.begin();
	for (; it != L1.end(); it++)
		it->prevPos = it->position;
		
	
	
	for (int j = 0; j < ans; j++)    // loops through how many teams you chose
	{
		k = 0;

		cout << "\nEnter the name of the college you wish to delete\n";
		cin.clear();      // flushes the input buffer
		fflush(stdin);
		getline(cin, temp);

		
		for (it = L1.begin(); it != L1.end(); it++)
		{
			++k;  // increment k for the loop
			
			if (it->name == temp)  // if the name matches the temp erase the node
			{
				L1.erase(it);
				break; 
			}
			
			 
			else if (k == i )   // else tell them they are stupid
			{
				cout << '\n' << temp << " not found. Updating previous entries\n\n";
				return 0;

			}
		}
		
		i--;  // decrement the team counter
		
	}
	


	i = 0;

	it = L1.begin();              // update the position
	for (; it != L1.end(); it++)
	{
		it->position = ++i;

	}

	return 0;


	

}

//************************************************************
//
// Function name: displayAll()
//
// Purpose: To display all of the standings
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: none
//************************************************************
void Standings::displayAll()
{

	list<Team>::iterator it;    // make the iterator


	cout << "\nAs of " << date << " the current AP top ncaa teams are:\n\n";
	cout << "Rank" << "  Team" << "             Record" << "  Votes" << "  Previous\n";


	it = L1.begin();

	for (; it!=L1.end(); it++)
	{
		if (it->votes == 0)        // erase any 0 entries
			L1.erase(it);

		if (it->position < 10)
			cout << it->position << "   ";    // spacing
		else
			cout << it->position << "  ";

		cout << it->name;
		for (int i = 0; i < (20 - it->name.length()); i++)     // spacing
			cout << ' ';
		cout << it->wins;

		cout << '-' << it->losses;
		if (it->losses < 10)
			cout << ' ';
		if (it->wins < 10)
			cout << ' ';
		cout << "  " << it->votes;



		if (it->votes > -1 && it->votes < 10)
			cout << "      ";
		else if (it->votes > 9 && it->votes < 100)   // spacing
			cout << "     ";
		else if (it->votes > 99 && it->votes < 1000)
			cout << "    ";
		else if (it->votes > 999 && it->votes < 10000)
			cout << "   ";

		if (it->prevPos == 0)
			cout << '-';
		else
			cout << it->prevPos;
		cout << endl;
	}
	cout << endl;
}


//************************************************************
//
// Function name: outFile()
//
// Purpose: To write to a file
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: none
//
//************************************************************

void Standings::outFile()
{
	ofstream fileOut;   // outfile
	string fileName;     // filename

	cout << "\nEnter the full name and path\n of the file you wish to write to\n";
	cin >> fileName;

	fileOut.open(fileName.c_str(), ios::out | ios::app);             // writes to file 

	if (!fileOut)
	{                                                                // exit if file doesnt open
		cerr << "\nFile could not be opened\n";
		exit(0);
	}

	list<Team>::iterator it;                 // make iterator


	fileOut <<   date << endl;
	


	it = L1.begin();

	for (; it != L1.end(); it++)
	{
		if (it->votes == 0)
			L1.erase(it);

		if (it->position < 10)
			fileOut << it->position << "   ";    // for spacing
		else
			fileOut << it->position << "  ";

		fileOut << it->name;
		for (int i = 0; i < (20 - it->name.length()); i++)   // iterates trough and writes
			fileOut << ' ';
		fileOut << it->wins;

		fileOut << '-' << it->losses;    // for losses
		if (it->losses < 10)
			fileOut << ' ';
		if (it->wins < 10)
			fileOut << ' ';
		fileOut << "  " << it->votes;



		if (it->votes > -1 && it->votes < 10)
			fileOut << "      ";
		else if (it->votes > 9 && it->votes < 100)    // for spacing
			fileOut << "     ";
		else if (it->votes > 99 && it->votes < 1000)
			fileOut << "    ";
		else if (it->votes > 999 && it->votes < 10000)
			fileOut << "   ";

		if (it->prevPos == 0)
			fileOut << '-';
		else
			fileOut << it->prevPos;
		fileOut << endl;

}

}


//************************************************************
//
// Function name: menu()
//
// Purpose: menu
//
// Input parameters: none
//
// Output parameters: none
//
// Return Value: none
//
//************************************************************

void Standings::menu()
{
	int num;   // for choice
	

	readFile();   // read in

	while (true){

		display();  // display top 25

		cout << "\n\n1.Display Top 25 Teams\n";
		cout << "2.Display All Teams\n";
		cout << "3.Adjust stats\n";
		cout << "4.Add a Team\n";
		cout << "5.Remove a Team\n";
		cout << "6.Write to File\n";
		cout << "7.End program\n";

		cin >> num;

		if (num == 1)
		{
			cout << "\n\nYou entered " << num << endl;   // for 25
			continue;
		}

		else if (num == 2)
		{
			cout << "\n\nYou entered " << num << endl;  // for all
			displayAll();
		}

		else if (num == 3)
		{
			cout << "\n\nYou entered " << num << endl;  // to adjust
			adjust();
		}

		else if (num == 4)
		{
			cout << "\n\nYou entered " << num << endl;// to add
			addElements();
		}

		else if (num == 5)
		{
			cout << "\n\nYou entered " << num << endl; // to remove 
			remove();
		}

		else if (num == 6)
		{
			cout << "\n\nYou entered " << num << endl; // to write
			outFile();
		}

		else if (num == 7)
		{
			cout << "\n\nYou entered " << num << endl;  // to end
			exit(0);
		}

		else
		{
			cout << "\nInvalid Entry\n";
		}

	}
}
